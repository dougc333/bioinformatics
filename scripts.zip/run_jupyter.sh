#!/bin/bash

jupyter notebook --no-browser

