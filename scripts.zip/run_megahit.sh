#!/bin/bash

time
megahit/megahit -1  SRR341725_1.fastq.gz -2 SRR341725_2.fastq.gz -o SRR341725.megahit_asm

