# test_model function
# function to test the model on new data set.
# input:
#  chem - drug-drug similarity database
#  phen - disease-disease similarity database
#  test_data - drug-disease associations
# output:
#  roc_auc - AUC of the predictive model run on the test data, must be single number

test_model <- function(chem, phen, test_data) {
  # load necessary packages
  require(dplyr)
  # if you need any other packages write
  # require('name of package') # replcing name of package
  # write as many times as the number of necessary packages
  
  # load custom feature function
  source('custom_feature_calculation.R')
  
  print('calculating features')
  # calculate features
  feature_matrix <- calculate_features(chem, phen,
                                       test_data %>% filter(known), test_data)
  
  # make sure that in your custom features calculating function you calculate
  # the same features that your model uses.
  
  # load predictive model
  load('predictive_model.Rdata')
  
  # calculate prediction on test_data and AUC
  
  # return the auc of the roc on the test set
  return(roc_auc)
}