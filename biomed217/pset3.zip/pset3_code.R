# code outline of problem set 3

# recommended packages
require(pROC) # make ROC plots easy
require(ggplot2) # pretty plots
require(dplyr) # easier data frame manipulation
require(data.table) # handles large data frames better

# set to desired directory
# setwd(YOUR DIRECTORY)

# load the data
load('pset3_data.Rdata')

# checkout some samples from the data
chem %>% head # precomputed drug-drug similarities
phen %>% head # precomputed disease-disease similarities
data %>% head # drug-disease pairs for prediction
drugbank_atc %>% head # drugbank to ATC mapping
umls_meddra %>% head # umls to medDRA mapping

###
# PART 1
### Computing features, add another section on computing similarities

# write SML query file, should be in the following format
# http://bio2rdf.org/meddra:10000056 =tab= http://bio2rdf.org/meddra:10000056

# open terminal in folder and run
#$ java -jar sml-toolkit.jar -t sm -xmlconf sml_mdr.conf

# read in similarities and combine with the provided phenotype data.

# source function that calculates features for predict
# implement predict in the sourced file!
source('predict_feature_calculation.R')

# calculate features
# implementation dependent, but this could take a while!

timestamp() # for timing, can also use system.time()
predict_features <- calculate_features(chem, phen,
                               data %>% filter(known),
                               data)
timestamp()

# other code to answer questions from part 1


###
# PART 2
### Fitting a predictive model

# seperate into train and test set
train <- predict_features %>% filter(group != 1)
test <- predict_features %>% filter(group == 1)

# fit a logistic regression model using training set

# run model on training set

# run model on test set

# train and run model on all for ATC section

# plot densities of ATC families

# other code to answer questions from part 2


###
# PART 3
### Alternative features and models

# source your custom feature calculation function
source('custom_feature_calculation.R')

custom_features <- calculate_features(chem, phen,
                                       data %>% filter(known),
                                       data)

# try out different machine learning algorithms

# plot ROC and save best AUC

# eventually save a model to use as a submission
# save(your_model, file = 'predictive_model.Rdata')

# load the function that tests your model
source('test_model.R') # make sure you implement it

# as a test, run this function on some sampled test_data
test_data <- data %>% sample_n(100) %>%
  select(-group) # because the heldout set will not have the group column

# This is the function I will run to test your model
# should run in under 30 minutes if you want a chance at extra points.
test_model(chem, phen, test_data)


