# calculate_features function
# input:
#  chem - drug-drug similarity database
#  phen - disease-disease similarity database
#  known - known drug-disease associations
#  unknown - unknown drug-disease associations
# output:
#  feature_matrix - return calculated features

calculate_features <- function(chem, phen, known, unknown) {
  
  #
  # IMPLEMENT PREDICT METHOD HERE
  #
  
  # return the feature matrix
  return(feature_matrix)
}