# calculate_features function
# input:
#  chem - drug-drug similarity database
#  phen - disease-disease similarity database
#  known - known drug-disease associations
#  unknown - unknown drug-disease associations
# output:
#  feature_matrix - return calculated features

calculate_features <- function(chem, phen, known, unknown) {
  # require(dplyr)
  # if you need any other packages write
  # require('name of package') # replcing name of package
  # write as many times as the number of necessary packages
  
  #
  # IMPLEMENT YOUR OWN FEATURE ENGINEERING HERE
  # should have the same columns that your model expects
  
  # return the feature matrix
  return(feature_matrix)
}